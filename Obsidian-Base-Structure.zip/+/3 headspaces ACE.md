![img](https://imgur.com/7l2YOi4.png)


---

---


- **A – Atlas** → *Stores references and general knowledge. It is the “map” of your ideas, concepts, and themes.*
- **C – Calendar** → *Holds everything related to dates: events, deadlines, and chronological records.*
- **E – Efforts** → *Contains your projects, tasks, and initiatives that require action.*
