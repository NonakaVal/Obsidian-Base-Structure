```base
views:
  - type: table
    name: View
    order:
      - file.name
    sort: []
    cardSize: 160
    imageAspectRatio: 1.15
    imageFit: contain

```
