> [!author]   **<% tp.system.prompt("author")%>** 
> *"<% tp.system.prompt("quote")%>"*