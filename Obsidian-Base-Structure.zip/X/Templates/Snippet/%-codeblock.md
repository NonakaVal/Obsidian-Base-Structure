```
 <% tp.system.clipboard() %>
```