---
kanban-plugin: board
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
---
