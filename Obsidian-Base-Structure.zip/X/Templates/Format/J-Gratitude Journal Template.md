---
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
tags:
  - Journaling
---

_Note: Feel free to use only the sections that resonate with you today. You can delete or leave blank any sections that don't apply._

# Three Things I'm Grateful For
_List three specific things you're thankful for today, big or small._
1.
2.
3.

# Person I'm Grateful For
 _Identify someone who has positively impacted your life recently and explain why._
- 

# Personal Accomplishment
_Acknowledge something you've achieved or a positive action you've taken, no matter how small._
- 

# Nature's Beauty
_Reflect on an aspect of nature that you appreciated today._
- 

# Unexpected Positive
 _Note something unexpectedly positive that happened today._
- 

# Gratitude Reflection
_Take a moment to reflect on how practicing gratitude has affected your day or overall outlook._
- 

