---
cover: https://i.imgur.com/oFWH7MM.png
---

↪[Collection](Collection.md)

# Coloured tab header container

---

- author:: rushi
- source::

---

cover:: ![](https://i.imgur.com/oFWH7MM.png)

```css
.workspace-tab-header-container {
  background-color: var(--text-accent); /* change this to your desired colour */
}

/* additional code for windows min,mix buttons */
.titlebar-button-container {
  background-color: transparent !important;
}
```

> _You might need to change colour of some elements inside the tab container_
