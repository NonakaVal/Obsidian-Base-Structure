---
cover: https://i.imgur.com/kWNrs1Q.png
---

↪[Collection](Collection.md)

# Unordered list styling 01

---

- author:: SlRvb, kneecaps
- source:: https://discord.com/channels/686053708261228577/931552763467411487/1022340935721439242

---

cover:: ![](https://i.imgur.com/kWNrs1Q.png)

```css
/*
author: SlRvb, kneecaps
source: https://discord.com/channels/686053708261228577/931552763467411487/1022340935721439242
*/

.list-bullet.list-bullet.list-bullet:after {
  content: "◈";
  height: unset;
  width: unset;
  background: transparent;
  margin-top: 5px;
  color: var(--text-accent);
}
```
