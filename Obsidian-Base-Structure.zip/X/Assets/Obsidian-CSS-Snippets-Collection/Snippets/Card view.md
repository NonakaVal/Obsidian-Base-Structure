---
cover: https://i.imgur.com/YN56k3S.png
---

↪[Collection](Collection.md)

# Card view

---

- author:: raisabelatrix
- source:: https://gist.github.com/raisabelatrix/a92a2c9c43c2deb2ebb5175f11631608

---

cover:: ![](https://i.imgur.com/YN56k3S.png)

```css

```
