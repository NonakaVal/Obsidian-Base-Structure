---
cover: https://i.imgur.com/0krxxi2.png
---

↪[Collection](Collection.md)

# Multicolumn note

---

- author:: zamsyt
- source:: https://github.com/zamsyt/obsidian-snippets/wiki/Easy-multi-column-notes

---

cover:: ![](https://i.imgur.com/0krxxi2.png)

```css

```

## How to use

```md
first column

---

---

second column
```
