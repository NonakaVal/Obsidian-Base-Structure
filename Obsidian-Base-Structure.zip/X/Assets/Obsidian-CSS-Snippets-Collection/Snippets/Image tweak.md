---
cover: https://i.imgur.com/xcJUzKw.png
---

↪[Collection](Collection.md)

# Image minimal tweak

---

- author:: rushi
- source::

---

> _Only works in light mode :)_

cover:: ![](https://i.imgur.com/xcJUzKw.png)

```css
img {
  border-radius: 4px;
  box-shadow: rgba(0, 0, 0, 0.45) 0px 25px 20px -26px;
}
```
