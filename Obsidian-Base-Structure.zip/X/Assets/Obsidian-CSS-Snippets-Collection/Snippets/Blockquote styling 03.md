---
cover: https://i.imgur.com/vxLR98e.png
---

↪[Collection](Collection.md)

# Blockquote styling 03

---

- author:: eleanorkonik
- source:: https://github.com/eleanorkonik/-palatinate/blob/main/fancy-blockquote.css

---

> _Only works in reading mode._

cover:: ![](https://i.imgur.com/vxLR98e.png)

```css

```

---

## How to use

```md
> Lorem ipsum dolor sit amet, consectetur, adipisicing elit. Iure minus voluptates illum aspernatur officia vel officiis, et quis qui. Enim omnis officia sunt consectetur obcaecati repudiandae! Numquam, voluptas at, ab officiis recusandae, dolorum inventore quod iste cumque explicabo dicta quidem accusantium velit odit deleniti, ipsum commodi?
> <cite>Name of the author</cite>
```
