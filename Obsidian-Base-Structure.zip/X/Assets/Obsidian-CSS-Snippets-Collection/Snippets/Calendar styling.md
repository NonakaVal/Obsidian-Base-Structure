↪[Collection](Collection.md)

# Calendar styling

---

- author:: sailKite
- source:: https://discord.com/channels/686053708261228577/702656734631821413/1168178314318458980

---

(cover::![](https://i.imgur.com/wvqLZ97.png))

---

```css
/*
author: sailKite
source: https://discord.com/channels/686053708261228577/702656734631821413/1168178314318458980
*/

.container#calendar-container .calendar {
  & > thead > tr:first-of-type {
    & > th:nth-child(1) {
      color: red;
    }
    & > th:nth-child(2) {
      color: orange;
    }
    & > th:nth-child(3) {
      color: yellow;
    }
    & > th:nth-child(4) {
      color: green;
    }
    & > th:nth-child(5) {
      color: blue;
    }
    & > th:nth-child(6) {
      color: indigo;
    }
    & > th:nth-child(7) {
      color: violet;
    }
  }
}
```
