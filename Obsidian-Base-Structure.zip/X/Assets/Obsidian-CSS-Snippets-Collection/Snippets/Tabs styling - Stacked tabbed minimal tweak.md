---
cover: https://i.imgur.com/kAsKDoX.png
---

↪[Collection](Collection.md)

# Tabs styling - Stacked tabbed minimal tweak

---

- author:: TheEmperor
- source:: https://forum.obsidian.md/t/vertical-tabs-for-more-efficient-use-of-space-and-easier-faster-navigation/42987/10?u

---

cover:: ![](https://i.imgur.com/kAsKDoX.png)

```css
/*
author: TheEmperor
source: https://forum.obsidian.md/t/vertical-tabs-for-more-efficient-use-of-space-and-easier-faster-navigation/42987/10?u
*/

.workspace
  .mod-root
  .workspace-tabs.mod-stacked
  .workspace-tab-container
  .workspace-tab-header-inner-title {
  text-orientation: upright;
  letter-spacing: -3px;
  text-transform: uppercase;
}
```
