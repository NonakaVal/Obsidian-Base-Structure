---
cover: https://i.imgur.com/hZFhK0I.png
---

↪[Collection](Collection.md)

# Code block styling 02

---

- author:: rushi
- source::

---

cover:: ![](https://i.imgur.com/hZFhK0I.png)

```css
.markdown-rendered pre {
  border-left: solid;
}

.markdown-source-view.mod-cm6 .cm-line.HyperMD-codeblock {
  border-left: solid;
}
```
