---
cover: https://i.imgur.com/M5CM6Ip.png
---

↪[Collection](Collection.md)

# Note icon

---

- author:: Trevor
- source:: https://discord.com/channels/686053708261228577/744933215063638183/1106245045834756229

---

cover:: ![](https://i.imgur.com/M5CM6Ip.png)

```css
/*
author: Trevor
source: https://discord.com/channels/686053708261228577/744933215063638183/1106245045834756229
*/

.workspace-tab-header[aria-label="Inbox"] .workspace-tab-header-inner-icon svg {
  -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100%' height='100%' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-inbox'%3E%3Cpolyline points='22 12 16 12 14 15 10 15 8 12 2 12'%3E%3C/polyline%3E%3Cpath d='M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z'%3E%3C/path%3E%3C/svg%3E");
  color: var(--icon-color);
  background-color: var(--icon-color);
}
```

[more info](https://discord.com/channels/686053708261228577/744933215063638183/1106245045834756229)
