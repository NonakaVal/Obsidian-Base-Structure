---
cover: https://i.imgur.com/KnhS6VY.png
---

↪[Collection](Collection.md)

# Accented settings side headings

---

- author:: rushi
- source::

---

> _Inspired from [Origami theme](https://github.com/7368697661/Origami) of_ **kneecaps.**

cover:: ![](https://i.imgur.com/KnhS6VY.png)

```css
.vertical-tab-header-group-title {
  color: var(--color-accent);
}
```
