---
cover: https://i.imgur.com/zDjkb9m.png
---

↪[Collection](Collection.md)

# Bigger first letter

---

- author:: FireIsGood
- source:: https://discord.com/channels/686053708261228577/702656734631821413/1091853109300559942

---

> _Extracted from the [original code](https://discord.com/channels/686053708261228577/702656734631821413/1091853109300559942)._

cover:: ![](https://i.imgur.com/zDjkb9m.png)

```css
:is(.cm-line, p, h1, h2, h3, h4, h5, h6)::first-letter {
  margin: 0.36rem;
  color: var(--text-normal);
  font-size: 2em;
  font-weight: bold;
  color: var(--text-accent);
}
```
