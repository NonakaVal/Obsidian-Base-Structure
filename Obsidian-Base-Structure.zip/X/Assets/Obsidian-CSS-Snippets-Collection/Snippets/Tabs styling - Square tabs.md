---
cover: https://i.imgur.com/1rH0K30.png
---

↪[Collection](Collection.md)

# Tabs styling - Square tabs

---

- author:: gavinmn
- source:: https://github.com/gavinmn/obsidian-theme/blob/main/square-tabs.css

---

cover:: ![](https://i.imgur.com/1rH0K30.png)

```css

```
