---
cover: https://i.imgur.com/oXNlnHH.png
---

↪[Collection](Collection.md)

# Popover Border (minimal tweak)

---

- author:: rushi
- source::

---

cover:: ![](https://i.imgur.com/oXNlnHH.png)

```css
.popover {
  border: solid var(--text-accent);
}
```
