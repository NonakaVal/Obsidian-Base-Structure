---
cover: https://i.imgur.com/Tpxc3uJ.png
---

↪[Collection](Collection.md)

# Table styling - Centred table

---

- author:: rushi
- source::

---

> _Only works in reading mode_

cover:: ![](https://i.imgur.com/Tpxc3uJ.png)

```css
.markdown-preview-view table {
  margin-left: auto;
  margin-right: auto;
}
```
