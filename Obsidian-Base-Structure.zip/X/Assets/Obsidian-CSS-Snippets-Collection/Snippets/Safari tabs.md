---
cover: https://i.imgur.com/TwpaIDT.png
---

↪[Collection](Collection.md)

# Tabs styling - Safari tabs

---

- author:: gavinmn
- source:: https://github.com/gavinmn/obsidian-theme/blob/main/safaritabs.css

---

cover:: ![](https://i.imgur.com/TwpaIDT.png)

```css

```
