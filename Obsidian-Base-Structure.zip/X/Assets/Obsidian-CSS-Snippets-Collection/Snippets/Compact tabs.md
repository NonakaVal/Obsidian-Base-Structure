---
cover: https://i.imgur.com/5TESm09.png
---

↪[Collection](Collection.md)

# Compact tabs

---

- author:: replete
- source:: https://github.com/replete/obsidian-minimal-theme-css-snippets/blob/main/%5Bui%5D%20Compact%20Tabs.css

---

cover:: ![](https://i.imgur.com/5TESm09.png)

```css

```
