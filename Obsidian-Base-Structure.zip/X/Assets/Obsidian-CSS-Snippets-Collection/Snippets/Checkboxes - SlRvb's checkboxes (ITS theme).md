---
cover: https://i.imgur.com/LiMKSfo.png
---

↪[Collection](Collection.md)

# Checkboxes - SlRvb's checkboxes (ITS theme)

---

- author:: SlRvb
- source:: https://github.com/SlRvb/Obsidian--ITS-Theme/blob/main/Guide/Alternate-Checkboxes.md

---

cover:: ![](https://i.imgur.com/LiMKSfo.png)

```css

```

---

## Usage

```md
- [ ] Unchecked
- [x] Regular
- [x] Checked
- [-] Dropped
- [>] Forward
- [D] Date
- [?] Question
- [/] Half Done
- [+] Add
- [R] Research
- [!] Important
- [i] Idea
- [B] Brainstorm
- [P] Pro
- [C] Con
- [Q] Quote
- [N] Note
- [b] Bookmark
- [I] Information
- [p] Paraphrase
- [L] Location
- [E] Example
- [A] Answer
- [r] Reward
- [c] Choice
- [d] Doing
- [T] Time
- [@] Character / Person
- [t] Talk
- [O] Outline / Plot
- [~] Conflict
- [W] World
- [f] Clue / Find
- [F] Foreshadow
- [H] Favorite / Health
- [&] Symbolism
- [s] Secret
```
