---
cover: https://i.imgur.com/QahcMIX.png
---

↪[Collection](Collection.md)

# Tags styling - Rainbow tags

---

- author:: raisabelatrix
- source:: https://gist.github.com/raisabelatrix/eb383f7e19b59f951430c2f3c6ed80b0

---

cover:: ![](https://i.imgur.com/QahcMIX.png)

```css

```
