---
cover: https://i.imgur.com/pyjIskI.png
---

↪[Collection](Collection.md)

# Left aligned note header (minimal tweak)

---

- author:: rushi
- source::

---

cover:: ![](https://i.imgur.com/pyjIskI.png)

```css
.view-header-title-container {
  justify-content: start;
}
```
