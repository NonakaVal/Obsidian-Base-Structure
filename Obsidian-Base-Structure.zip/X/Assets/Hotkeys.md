---
created: "[[2025-05-30]]"
cssclasses:
  - hide-properties_reading
  - hide-properties_editing
---

| 🎛️ Paleta de comandos | `Ctrl + P`         |
| ---------------------- | ------------------ |
| ➡️ Quick Switcher      | `Ctrl + O`         |
| 🗓️ Daily Note         | `Ctrl + Shift + D` |
| 📌 Fixar/Desfixar nota | `Alt + F`          |
| ➕ New Note             | `Ctrl + N`         |
| 🧠 Show Local Graph    | `Ctrl + G`         |
| 🔖 Add (Footnote)      | `Ctrl + Shift + V` |
| 🔖 Add File Property   | `Ctrl + ;`         |
| 📑 Show Bookmarks      | `Ctrl + Shift + B` |
| ⭐ Bookmark All Tabs    | `Alt + B`          |
| 🗂️ File Explorer      | `Ctrl + Shift + P` |
| 📄 Show Outline        | `Ctrl + Shift + O` |
| 🔍 Search in Files     | `Ctrl + Shift + F` |
| 🚪 Close Tab           | `Ctrl + W`         |
| 🚪 Close Window        | `Ctrl + Shift + W` |
| 🗑️ Delete File        | `Ctrl + Shift + -` |
| 📦 Move File           | `Alt + M`          |
