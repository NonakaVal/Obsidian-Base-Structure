---
created: '[[2025-09-19]]'
---

> [!multi-column]
>
>> [!todo|wide-2]+  Areas
>>  ![[@_areas]]
>
>> [!Blocks|wide-5]+ Projects
>> ![[@_projects]]

