---
cssclasses:
  - wide-page
---

> [!multi-column]
>
>> [!leaf]+ Garden
>> ![[@_Garden]]
>
>> [!wrench|wide]+ Architect
>> ![[@_Architect]]


